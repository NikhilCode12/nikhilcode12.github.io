# HTML/CSS PROJECTS
Basic Projects using only HTML and CSS - Created By Nikhil Sharma

Projects included are detailed below: 
# 1. Tribute Web Page
<ul><li>In this I created a tribute webpage to Late Lata Mangeshkar Ji using Some Basic CSS and HTML.</li></ul>

# 2. Landing Web Page
<ul>
<li>Created Developer Landing WebPage</li>
<li>Responsive Styling Using CSS MediaQueries</li>
<li>CSS FlexBox and Grids Concept Used</li>
</ul>

# 3. Job Application Form
<ul>
<li>Created Developer Application Form</li>
<li>HTML Input, Label, Form, TextArea... elements Used</li>
<li>CSS MediaQueries Used For Responsive Design</li>
</ul>
